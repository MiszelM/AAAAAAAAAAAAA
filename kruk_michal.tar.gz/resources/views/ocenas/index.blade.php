<x-layouts.app>
    <div class="p-6">
        <flux:heading size="xl" class="mb-6">Analizy Zdolności Kredytowej</flux:heading>
        <div class="bg-white dark:bg-zinc-900 border border-zinc-200 rounded-xl p-6">
            <livewire:ocena-table />
        </div>
    </div>
</x-layouts.app>